# Save Notes Locally

Obsidian lets you save all your notes locally on your computer.

Go to [[index]]