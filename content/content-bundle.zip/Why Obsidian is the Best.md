# Obsidian is the best notetaking app

Looking for a notetaking app that saves information locally on your computer? Look no further because you can't find an app better than Obsidian.

Go back to [[index]]