# Welcome to The Matrix

Just a collection of my thoughts!

- [[Why Obsidian is the Best]]
- [[Save Notes Locally on Your Computer]]

